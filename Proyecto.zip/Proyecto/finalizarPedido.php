<?php
session_start();
require "administrador/funciones/conecta.php";
$con = conecta();

// Función para actualizar el estado del pedido
function actualizarEstadoPedido($id_pedido) {
    global $con;
    $sql = "UPDATE pedidos SET status = 1 WHERE id = ?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("i", $id_pedido);
    $stmt->execute();
    $stmt->close();
}

// Función para actualizar el stock de productos
function actualizarStockProductos($id_producto, $cantidad_vendida) {
    global $con;
    $sql = "UPDATE productos SET stock = stock - ? WHERE id = ?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("ii", $cantidad_vendida, $id_producto);
    $stmt->execute();
    $stmt->close();
}

// Verificar si se proporciona el ID del pedido
if (!isset($_GET['id_pedido'])) {
    $_SESSION['mensaje_error'] = "ID del pedido no proporcionado.";
    header("Location: productos_listaClientes.php");
    exit;
}

$id_pedido = $_GET['id_pedido'];

// Actualizar el estado del pedido a 1 (completado)
try {
    actualizarEstadoPedido($id_pedido);
} catch (Exception $e) {
    $_SESSION['mensaje_error'] = "Error al actualizar el estado del pedido.";
    header("Location: productos_listaClientes.php");
    exit;
}

// Obtener los productos vendidos en el pedido
$sql_productos_pedido = "SELECT id_producto, cantidad FROM pedidos_productos WHERE id_pedido = ?";
$stmt_productos_pedido = $con->prepare($sql_productos_pedido);
$stmt_productos_pedido->bind_param("i", $id_pedido);
$stmt_productos_pedido->execute();
$res_productos_pedido = $stmt_productos_pedido->get_result();

// Restar la cantidad vendida del stock disponible en la tabla de productos
while ($row_producto_pedido = $res_productos_pedido->fetch_assoc()) {
    $id_producto = $row_producto_pedido['id_producto'];
    $cantidad_vendida = $row_producto_pedido['cantidad'];

    // Actualizar el stock en la tabla de productos
    try {
        actualizarStockProductos($id_producto, $cantidad_vendida);
    } catch (Exception $e) {
        $_SESSION['mensaje_error'] = "Error al actualizar el stock de productos.";
        header("Location: productos_listaClientes.php");
        exit;
    }
}

// Redireccionar a una página de confirmación o a donde desees
header("Location: /Proyecto/administrador/funciones/bienvenidoClientes.php");
?>
