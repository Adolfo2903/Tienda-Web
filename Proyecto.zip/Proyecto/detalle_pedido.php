<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalle del Pedido</title>
    <!-- Estilos CSS -->
    <style>
        /* Estilos CSS */
        body {
            font-family: Optima, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #e4fcd8;
        }
        
        .container {
            max-width: 800px;
            margin: 0px auto;
            padding: 20px;
            background-color: #DAF7A6;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: #44782a;
        }

        h3 {
            color: #44782a;
        }

        /* Estilos para la tabla */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #98b649;
            color: white;
        }

        /* Estilos para el encabezado */
        header {
            background-color: #e4fcd8;
            color: #44782a;
            padding: 10px 0;
            text-align: center;
        }
        header h1 {
            margin: 0;
            font-size: 26px;
        }

        /* Estilos para la barra de navegación */
        nav ul {
            list-style-type: none;
            padding: 0;
            text-align: center;
            margin-top: 20px;
        }
        nav ul li {
            display: inline;
            margin-right: 20px;
        }
        nav ul li a {
            text-decoration: none;
            color: #44782a;
            font-size: 26px;
        }
        nav ul li a:hover {
            text-decoration: underline;
        }
        header .img {
            max-width: 60px;
            height: auto;
            float: left;
        }
    </style>
</head>
<body>

    <header>
        <div class="container">
            <img src="/Proyecto/administrador/logo/logoP.jpg" class="img">

            <nav>
                <ul>
                    <li><a href="administrador/funciones/bienvenido.php">Home</a></li>
                    <li><a href="administrador/funciones/inicio.php">Empleados</a></li>
                    <li><a href="productos_lista.php">Productos</a></li>
                    <li><a href="promociones_lista.php">Promociones</a></li>
                    <li><a href="productosCerrados.php">Pedidos</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="container">
        <?php
        // Conexión a la base de datos y otras configuraciones necesarias
        require_once("administrador/funciones/conecta.php");

        // Verificar si se ha pasado un ID de pedido en la URL
        if (isset($_GET['id'])) {
            // Obtener el ID del pedido desde la URL
            $pedido_id = $_GET['id'];

            // Consultar la base de datos para obtener los detalles del pedido con el ID proporcionado
            $con = conecta();
            $sql_pedido = "SELECT * FROM pedidos WHERE id = $pedido_id";
            $result_pedido = $con->query($sql_pedido);

            // Verificar si se encontró algún resultado
            if ($result_pedido->num_rows > 0) {
                $pedido = $result_pedido->fetch_assoc(); // Obtener los detalles del pedido

                // Consultar la base de datos para obtener los productos asociados al pedido
                $sql_productos = "SELECT pp.*, p.nombre AS nombre_producto, p.costo AS precio_unitario FROM pedidos_productos pp INNER JOIN productos p ON pp.id_producto = p.id WHERE pp.id_pedido = $pedido_id";
                $result_productos = $con->query($sql_productos);

                ?>
                <h2>Detalle del Pedido</h2>
                <p><strong>ID del Pedido:</strong> <?php echo $pedido["id"]; ?></p>
                <p><strong>Fecha del Pedido:</strong> <?php echo $pedido["fecha"]; ?></p>
                
                <h3>Productos:</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Producto</th>
                            <th>Cantidad</th>
                            <th>Precio Unitario</th>
                            <th>Costo</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    $total_pedido = 0; // Inicializar el total del pedido
                    // Mostrar los productos asociados al pedido
                    if ($result_productos->num_rows > 0) {
                        while ($producto = $result_productos->fetch_assoc()) {
                            $costo_producto = $producto['cantidad'] * $producto['precio_unitario']; // Calcular el costo del producto
                            $total_pedido += $costo_producto; // Sumar al total del pedido
                            echo "<tr>";
                            echo "<td>{$producto['nombre_producto']}</td>";
                            echo "<td>{$producto['cantidad']}</td>";
                            echo "<td>{$producto['precio_unitario']}</td>";
                            echo "<td>$costo_producto</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='4'>No hay productos asociados a este pedido.</td></tr>";
                    }
                    ?>
                    </tbody>
                </table>

                <p><strong>Total del Pedido:</strong> <?php echo $total_pedido; ?></p>

                <!-- Agrega más detalles del pedido según sea necesario -->

                <?php
            } else {
                echo "<p>No se encontró ningún pedido con el ID proporcionado.</p>";
            }
        } else {
            // Si no se proporcionó ningún ID de pedido válido, mostrar un mensaje de error o redireccionar a otra página
            echo "<p>No se proporcionó un ID de pedido válido.</p>";
        }
        ?>
    </div>

    <footer style="background-color: #e4fcd8; color: #44782a; text-align: center; padding: 20px;">
        <div>
            <p>Derechos Reservados &copy; <?php echo date("Y"); ?></p>
            <p><a href="#">Términos y Condiciones</a></p>
            <p>Redes Sociales: <a href="#">Facebook</a>, <a href="#">Twitter</a>, <a href="#">Instagram</a></p>
        </div>
    </footer>
    
</body>
</html>
