<?php
// verPedido.php
session_start();
require "administrador/funciones/conecta.php";
$con = conecta();

$id_cliente = $_SESSION['usuario_id'];

// Obtener el pedido activo del cliente
$sql = "SELECT * FROM pedidos WHERE id_cliente = $id_cliente AND status = 0";
$res = $con->query($sql);
$num = $res->num_rows;

if ($num == 0) {
    header("Location: pagina_sinPedido.php");
    exit;
} else {
    $pedido = $res->fetch_assoc();
    $id_pedido = $pedido['id'];
}

// Obtener los productos del pedido
$sql = "SELECT pp.id, p.nombre, p.descripcion, pp.cantidad, pp.precio, p.stock
        FROM pedidos_productos pp
        JOIN productos p ON pp.id_producto = p.id
        WHERE pp.id_pedido = $id_pedido";
$res = $con->query($sql);
$num_productos = $res->num_rows;
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi Pedido</title>
    <style>
        body {
            font-family: Optima, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #e4fcd8;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #DAF7A6;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        h2 {
            color: #44782a;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ccc;
        }
        th, td {
            padding: 10px;
            text-align: center;
        }
        .update-quantity {
            width: 50px;
            text-align: center;
        }
        .action-button {
            background-color: #dc3545;
            color: #fff;
            border: none;
            padding: 5px 10px;
            border-radius: 3px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .action-button:hover {
            background-color: #c82333;
        }
        .back-to-products-button {
            background-color: #98b649;
            color: #fff;
            border: none;
            padding: 8px 16px;
            border-radius: 3px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            transition: background-color 0.3s;
        }
        .back-to-products-button:hover {
            background-color: #323f0e;
        }

        /* Estilos para el encabezado */
        header {
            background-color: #e4fcd8;
            color: #44782a;
            padding: 10px 0;
            text-align: center;
        }
        header h1 {
            margin: 0;
            font-size: 26px;
        }
        /* Estilos para la barra de navegación */
        nav ul {
            list-style-type: none;
            padding: 0;
            text-align: center;
            margin-top: 20px;
        }
        nav ul li {
            display: inline;
            margin-right: 20px;
        }
        nav ul li a {
            text-decoration: none;
            color: #44782a;
            font-size:30px;
        }
        nav ul li a:hover {
            text-decoration: underline;
        }
        header .img{
            max-width: 80px;
            height: auto;
            float: left;

        }
        
    </style>
</head>
<body>

    <header>
        <div class="container">
        <img src="/Proyecto/administrador/logo/logoP.jpg" class="img">

            <nav>
                <ul>
                    <li><a href="administrador/funciones/bienvenidoClientes.php">Home</a></li>
                    <li><a href="productos_listaClientes.php">Productos</a></li>
                    <li><a href="contacto.php">Contacto</a></li>
                    <li><a href="verPedido.php">Carrito</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="container">
        <h2>Mi Pedido</h2>
        <?php if ($num_productos > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Producto</th>
                        <th>Descripción</th>
                        <th>Cantidad</th>
                        <th>Stock Disponible</th>
                        <th>Precio Unitario</th>
                        <th>Subtotal</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $total = 0;
                    while ($row = $res->fetch_assoc()):
                        $subtotal = $row['cantidad'] * $row['precio'];
                        $total += $subtotal;
                    ?>
                        <tr>
                            <td><?php echo $row['nombre']; ?></td>
                            <td><?php echo $row['descripcion']; ?></td>
                            <form action="actualizarCantidad.php" method="POST">
                                <td>
                                    <input type="hidden" name="id_pedido_producto" value="<?php echo $row['id']; ?>">
                                    <input type="number" name="cantidad" class="update-quantity" value="<?php echo $row['cantidad']; ?>" min="1" max="<?php echo $row['stock']; ?>">
                                    <button type="submit" class="action-button">Actualizar</button>
                                </td>
                            </form>
                            <td><?php echo $row['stock']; ?></td>
                            <td>$ <?php echo number_format($row['precio'], 2); ?></td>
                            <td>$ <?php echo number_format($subtotal, 2); ?></td>
                            <td>
                                <form action="eliminarProducto.php" method="POST">
                                    <input type="hidden" name="id_pedido_producto" value="<?php echo $row['id']; ?>">
                                    <button type="submit" class="action-button">Eliminar</button>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="5" style="text-align: right;"><strong>Total:</strong></td>
                        <td colspan="2">$ <?php echo number_format($total, 2); ?></td>
                    </tr>
                </tfoot>
            </table>
            <br>
            <a href="productos_listaClientes.php" class="back-to-products-button">Continuar comprando</a>
            <a href="verPedido2.php" class="back-to-products-button">Continuar</a>
        <?php else: ?>
            <p>No hay productos en tu pedido.</p>
            <a href="productos_listaClientes.php" class="back-to-products-button">Ver productos</a>
        <?php endif; ?>
    </div>

    <footer style="background-color: #e4fcd8; color: #44782a; text-align: center; padding: 20px;">
        <div>
            <p>Derechos Reservados &copy; <?php echo date("Y"); ?></p>
            <p><a href="#">Términos y Condiciones</a></p>
            <p>Redes Sociales: <a href="#">Facebook</a>, <a href="#">Twitter</a>, <a href="#">Instagram</a></p>
        </div>
    </footer>
</body>
</html>
