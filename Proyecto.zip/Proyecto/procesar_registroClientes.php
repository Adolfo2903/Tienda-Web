<?php
require("administrador/funciones/conecta.php");

// Verificar si se enviaron datos mediante el método POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verificar la existencia de datos y validarlos
    if (isset($_POST["nombre"]) && isset($_POST["apellidos"]) && isset($_POST["correo"]) && isset($_POST["password"])) {

        $nombre = trim($_POST["nombre"]);
        $apellidos = trim($_POST["apellidos"]);
        $correo = trim($_POST["correo"]);
        $password = trim($_POST["password"]);

        // Validar el correo electrónico
        if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
            echo "El correo electrónico ingresado no es válido.";
            exit();
        }

        // Crear una conexión a la base de datos
        $con = conecta();

        // Preparar la consulta SQL para insertar un nuevo cliente
        $sql = "INSERT INTO clientes (nombre, apellidos, correo, pass) VALUES (?, ?, ?, ?)";

        // Preparar la declaración
        $stmt = $con->prepare($sql);

        // Vincular los parámetros
        $stmt->bind_param("ssss", $nombre, $apellidos, $correo, $password);

        // Ejecutar la consulta
        if ($stmt->execute()) {
            // Redireccionar a la página de lista de clientes
            header("Location: /Proyecto/administrador/funciones/indexClientes.php");
            exit();
        } else {
            // Mostrar un mensaje de error si la inserción falla
            echo "Error al registrar el cliente: " . $con->error;
        }

        // Cerrar la conexión
        $stmt->close();
        $con->close();
    } else {
        // Mostrar un mensaje de error si faltan datos
        echo "Por favor, complete todos los campos obligatorios.";
    }
}
?>
