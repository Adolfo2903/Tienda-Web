<?php
//empleados_lista.php
require_once("administrador/funciones/conecta.php");
require_once("administrador/funciones/eliminar_usuario.php");
require_once("administrador/funciones/verificar_correo.php");

$con = conecta();
$sql = "SELECT * FROM empleados WHERE status = 1";
$result = $con->query($sql);
$num = $result->num_rows;
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listado de Empleados</title>
    <!-- Estilos CSS -->
    <style>
        /* Estilos CSS */
        body {
            font-family: Optima, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #e4fcd8;
        }
        
        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #DAF7A6;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .employee {
            border-bottom: 1px solid #ddd;
            padding: 10px 0;
            display: flex; /* Alinear elementos en fila */
        }

        .employee-info {
            margin-bottom: 10px;
            flex: 1; /* Que ocupe el espacio restante */
        }

        .employee-info strong {
            margin-right: 5px;
            color: #333;
        }

        .employee-image {
            margin-right: 20px;
        }

        .employee-image img {
            width: 100px; /* Tamaño fijo de la imagen */
            height: 100px; /* Tamaño fijo de la imagen */
            object-fit: cover; /* Ajustar la imagen para que cubra el contenedor */
            border-radius: 50%; /* Hacer la imagen redonda */
        }

        .employee-actions a {
            margin-right: 10px;
            color: #007bff;
            text-decoration: none;
        }

        .employee-actions a:hover {
            text-decoration: underline;
        }

        .no-employees {
            margin-top: 20px;
            text-align: center;
            font-style: italic;
            color: #888;
        }

        .employee-actions button {
            background-color: #dc3545; /* Color de fondo del botón */
            color: #fff; /* Color del texto del botón */
            border: none; /* Quitamos el borde del botón */
            padding: 5px 10px; /* Espaciado interno del botón */
            border-radius: 3px; /* Borde redondeado */
            cursor: pointer; /* Cambiamos el cursor al pasar sobre el botón */
            transition: background-color 0.3s; /* Efecto de transición suave */
        }

        .employee-actions button:hover {
            background-color: #c82333; /* Cambio de color al pasar el cursor sobre el botón */
        }

        .back-to-menu-button {
            background-color: #98b649; /* Color de fondo del botón */
            color: #fff; /* Color del texto del botón */
            border: none; /* Quitamos el borde del botón */
            padding: 8px 16px; /* Espaciado interno del botón */
            border-radius: 3px; /* Borde redondeado */
            cursor: pointer; /* Cambiamos el cursor al pasar sobre el botón */
            text-decoration: none; /* Quitamos el subrayado del enlace */
            display: inline-block; /* Para que el enlace se comporte como un bloque */
            transition: background-color 0.3s; /* Efecto de transición suave */
        }

        .back-to-menu-button:hover {
            background-color: #323f0e; /* Cambio de color al pasar el cursor sobre el botón */
        }

        .back-to-add-button {
            background-color: #98b649; /* Color de fondo del botón */
            color: #fff; /* Color del texto del botón */
            border: none; /* Quitamos el borde del botón */
            padding: 8px 16px; /* Espaciado interno del botón */
            border-radius: 3px; /* Borde redondeado */
            cursor: pointer; /* Cambiamos el cursor al pasar sobre el botón */
            text-decoration: none; /* Quitamos el subrayado del enlace */
            display: inline-block; /* Para que el enlace se comporte como un bloque */
            transition: background-color 0.3s; /* Efecto de transición suave */
        }

        .back-to-add-button:hover {
            background-color: #323f0e; /* Cambio de color al pasar el cursor sobre el botón */
        }
        

        h2{
            color:  #44782a ;
        }

        .employee-actions a.button {
            background-color: #98b649; /* Color de fondo del botón */
            color: #fff; /* Color del texto del botón */
            border: none; /* Quitamos el borde del botón */
            padding: 5px 10px; /* Espaciado interno del botón */
            border-radius: 3px; /* Borde redondeado */
            cursor: pointer; /* Cambiamos el cursor al pasar sobre el botón */
            text-decoration: none; /* Quitamos el subrayado del enlace */
            transition: background-color 0.3s; /* Efecto de transición suave */
        }

        .employee-actions a.button:hover {
            background-color: #323f0e; /* Cambio de color al pasar el cursor sobre el botón */
        }

        /* Estilos para el encabezado */
        header {
            background-color: #e4fcd8;
            color: #44782a;
            padding: 10px 0;
            text-align: center;
        }
        header h1 {
            margin: 0;
            font-size: 26px;
        }
        /* Estilos para la barra de navegación */
        nav ul {
            list-style-type: none;
            padding: 0;
            text-align: center;
            margin-top: 20px;
        }
        nav ul li {
            display: inline;
            margin-right: 20px;
        }
        nav ul li a {
            text-decoration: none;
            color: #44782a;
            font-size:30px;
        }
        nav ul li a:hover {
            text-decoration: underline;
        }
        header .img{
            max-width: 80px;
            height: auto;
            float: left;

        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #DAF7A6;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            
        }

</style>
        
    </style>
</head>
<body>

    <header>
        <div class="container">
        <img src="/Proyecto/administrador/logo/logoP.jpg" class="img">

            <nav>
                <ul>
                    <li><a href="administrador/funciones/bienvenido.php">Home</a></li>
                    <li><a href="administrador/funciones/inicio.php">Empleados</a></li>
                    <li><a href="productos_lista.php">Productos</a></li>
                    <li><a href="promociones_lista.php">Promociones</a></li>
                    <li><a href="productosCerrados.php">Pedidos</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="container">
        <h2>Listado de empleados (<?php echo $num; ?>)</h2>
        <!--<a href="empleados_alta.php" class="back-to-add-button">Añadir Empleado</a><br><br>-->

        <?php while ($row = $result->fetch_array()) { ?>
            <div class="employee">
                <div class="employee-image">
                    <img src="administrador/fotos_empleados/<?php echo $row["foto_nombre_encriptado"]; ?>" alt="Foto de perfil" class="employee-image">
                </div>
                <div class="employee-info">
                    <strong>ID:</strong><?php echo $row["id"]; ?><br>
                    <strong>Correo:</strong><?php echo $row["correo"]; ?><br>
                </div>
                <div class="employee-actions">
                    <a href="administrador/funciones/ver_detalle.php?id=<?php echo $row["id"]; ?>" class="button">Ver detalle</a>
                    <a href="administrador/funciones/editar_empleado.php?id=<?php echo $row["id"]; ?>" class="button">Editar</a>
                    <button class="delete-button" data-id="<?php echo $row["id"]; ?>">Eliminar</button>
                </div>
            </div>
        <?php } ?>

        <!--<a href="administrador/funciones/inicio.php" class="back-to-menu-button">Regresar al Menú</a>-->

    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            $(".delete-button").click(function() {
                var id = $(this).data("id");
                if (confirm("¿Estás seguro de que quieres eliminar este usuario?")) {
                    $.ajax({
                        type: "POST",
                        url: "administrador/funciones/eliminar_usuario.php",
                        data: { id: id },
                        success: function(response) {
                            // La eliminación fue exitosa, recargar la página o actualizar la lista de empleados
                            window.location.reload(); // O cualquier otra acción que desees realizar
                        },
                        error: function(xhr, status, error) {
                            // Hubo un error al eliminar el usuario
                            console.error("Error al eliminar el usuario:", error);
                        }
                    });
                }
            });
        });
    </script>

<footer style="background-color: #e4fcd8; color: #44782a; text-align: center; padding: 20px;">
        <div>
            <p>Derechos Reservados &copy; <?php echo date("Y"); ?></p>
            <p><a href="#">Términos y Condiciones</a></p>
            <p>Redes Sociales: <a href="#">Facebook</a>, <a href="#">Twitter</a>, <a href="#">Instagram</a></p>
        </div>
    </footer>
</body>
</html>