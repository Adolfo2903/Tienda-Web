<?php
//empleados_lista.php
require_once("administrador/funciones/conecta.php");
require_once("administrador/funciones/eliminar_promocion.php");

$con = conecta();
$sql = "SELECT * FROM promociones WHERE status = 1";
$result = $con->query($sql);
$num = $result->num_rows;
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listado de Promociones</title>
    <!-- Estilos CSS -->
    <style>
        /* Estilos CSS */
        body {
            font-family: Optima, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #e4fcd8;
        }
        
        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #DAF7A6;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .product {
            border-bottom: 1px solid #ddd;
            padding: 10px 0;
            display: flex; /* Alinear elementos en fila */
        }

        .product-info {
            margin-bottom: 10px;
            flex: 1; /* Que ocupe el espacio restante */
        }

        .product-info strong {
            margin-right: 5px;
            color: #333;
        }

        .product-image {
            margin-right: 20px;
        }

        .product-image img {
            width: 100px; /* Tamaño fijo de la imagen */
            height: 100px; /* Tamaño fijo de la imagen */
            object-fit: cover; /* Ajustar la imagen para que cubra el contenedor */
            border-radius: 5px; /* Borde redondeado */
        }

        .product-actions a {
            margin-right: 10px;
            color: #007bff;
            text-decoration: none;
        }

        .product-actions a:hover {
            text-decoration: underline;
        }

        .no-products {
            margin-top: 20px;
            text-align: center;
            font-style: italic;
            color: #888;
        }

        .product-actions button {
            background-color: #dc3545; /* Color de fondo del botón */
            color: #fff; /* Color del texto del botón */
            border: none; /* Quitamos el borde del botón */
            padding: 5px 10px; /* Espaciado interno del botón */
            border-radius: 3px; /* Borde redondeado */
            cursor: pointer; /* Cambiamos el cursor al pasar sobre el botón */
            transition: background-color 0.3s; /* Efecto de transición suave */
        }

        .product-actions button:hover {
            background-color: #c82333; /* Cambio de color al pasar el cursor sobre el botón */
        }

        .back-to-add-button {
            background-color: #98b649; /* Color de fondo del botón */
            color: #fff; /* Color del texto del botón */
            border: none; /* Quitamos el borde del botón */
            padding: 8px 16px; /* Espaciado interno del botón */
            border-radius: 3px; /* Borde redondeado */
            cursor: pointer; /* Cambiamos el cursor al pasar sobre el botón */
            text-decoration: none; /* Quitamos el subrayado del enlace */
            display: inline-block; /* Para que el enlace se comporte como un bloque */
            transition: background-color 0.3s; /* Efecto de transición suave */
        }

        .back-to-add-button:hover {
            background-color: #323f0e; /* Cambio de color al pasar el cursor sobre el botón */
        }

        .back-to-menu-button {
            background-color: #98b649; /* Color de fondo del botón */
            color: #fff; /* Color del texto del botón */
            border: none; /* Quitamos el borde del botón */
            padding: 8px 16px; /* Espaciado interno del botón */
            border-radius: 3px; /* Borde redondeado */
            cursor: pointer; /* Cambiamos el cursor al pasar sobre el botón */
            text-decoration: none; /* Quitamos el subrayado del enlace */
            display: inline-block; /* Para que el enlace se comporte como un bloque */
            transition: background-color 0.3s; /* Efecto de transición suave */
        }

        .back-to-menu-button:hover {
            background-color: #323f0e; /* Cambio de color al pasar el cursor sobre el botón */
        }

        .promotions-actions a.button {
            background-color: #98b649; /* Color de fondo del botón */
            color: #fff; /* Color del texto del botón */
            border: none; /* Quitamos el borde del botón */
            padding: 5px 10px; /* Espaciado interno del botón */
            border-radius: 3px; /* Borde redondeado */
            cursor: pointer; /* Cambiamos el cursor al pasar sobre el botón */
            text-decoration: none; /* Quitamos el subrayado del enlace */
            transition: background-color 0.3s; /* Efecto de transición suave */
        }

        .promotions-actions a.button:hover {
            background-color: #323f0e; /* Cambio de color al pasar el cursor sobre el botón */
        }
        .promotions-actions button {
            background-color: #dc3545; /* Color de fondo del botón */
            color: #fff; /* Color del texto del botón */
            border: none; /* Quitamos el borde del botón */
            padding: 5px 10px; /* Espaciado interno del botón */
            border-radius: 3px; /* Borde redondeado */
            cursor: pointer; /* Cambiamos el cursor al pasar sobre el botón */
            transition: background-color 0.3s; /* Efecto de transición suave */
        }

        .promotions-actions button:hover {
            background-color: #c82333; /* Cambio de color al pasar el cursor sobre el botón */
        }

        h2{
            color:  #44782a ;
        }
        /* Estilos para el encabezado */
        header {
            background-color: #e4fcd8;
            color: #44782a;
            padding: 10px 0;
            text-align: center;
        }
        header h1 {
            margin: 0;
            font-size: 26px;
        }
        /* Estilos para la barra de navegación */
        nav ul {
            list-style-type: none;
            padding: 0;
            text-align: center;
            margin-top: 20px;
        }
        nav ul li {
            display: inline;
            margin-right: 20px;
        }
        nav ul li a {
            text-decoration: none;
            color: #44782a;
            font-size:30px;
        }
        nav ul li a:hover {
            text-decoration: underline;
        }
        header .img{
            max-width: 80px;
            height: auto;
            float: left;

        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #DAF7A6;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            
        }


    </style>
</head>
<body>

    <header>
        <div class="container">
        <img src="/Proyecto/administrador/logo/logoP.jpg" class="img">

            <nav>
                <ul>
                    <li><a href="administrador/funciones/bienvenido.php">Home</a></li>
                    <li><a href="administrador/funciones/inicio.php">Empleados</a></li>
                    <li><a href="productos_lista.php">Productos</a></li>
                    <li><a href="promociones_lista.php">Promociones</a></li>
                    <li><a href="productosCerrados.php">Pedidos</a></li>
                </ul>
            </nav>
        </div>
    </header>


    <div class="container">
        <h2>Listado de Promociones (<?php echo $num; ?>)</h2>
        <a href="promociones_alta.php" class="back-to-add-button">Añadir Promocion</a><br><br>
        
        <?php while ($row = $result->fetch_array()) { ?>
            <div class="product">
                <div class="product-image">
                    <img src="administrador/fotos_promociones/<?php echo $row["archivo"]; ?>" alt="Foto de la promocion" class="product-image">
                </div>
                <div class="product-info">
                    <strong>Nombre:</strong><?php echo $row["nombre"]; ?><br>
                </div>
                <div class="promotions-actions">
                    <a href="administrador/funciones/ver_detallePromocion.php?id=<?php echo $row["id"]; ?>" class="button">Ver detalle</a>
                    <a href="administrador/funciones/editar_promocion.php?id=<?php echo $row["id"]; ?>" class="button">Editar</a>
                    <button class="delete-button" data-id="<?php echo $row["id"]; ?>">Eliminar</button>
                </div>
            </div>
        <?php } ?>
        <!--<a href="administrador/funciones/bienvenido.php" class="back-to-menu-button">Regresar al Menú</a>-->

    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            $(".delete-button").click(function() {
                var id = $(this).data("id");
                if (confirm("¿Estás seguro de que quieres eliminar esta promocion?")) {
                    $.ajax({
                        type: "POST",
                        url: "administrador/funciones/eliminar_promocion.php",
                        data: { id: id },
                        success: function(response) {
                            // La eliminación fue exitosa, recargar la página o actualizar la lista de productos
                            window.location.reload(); // O cualquier otra acción que desees realizar
                        },
                        error: function(xhr, status, error) {
                            // Hubo un error al eliminar el producto
                            console.error("Error al eliminar el promocion:", error);
                        }
                    });
                }
            });
        });
    </script>

<footer style="background-color: #e4fcd8; color: #44782a; text-align: center; padding: 20px;">
        <div>
            <p>Derechos Reservados &copy; <?php echo date("Y"); ?></p>
            <p><a href="#">Términos y Condiciones</a></p>
            <p>Redes Sociales: <a href="#">Facebook</a>, <a href="#">Twitter</a>, <a href="#">Instagram</a></p>
        </div>
    </footer>

</body>
</html>
