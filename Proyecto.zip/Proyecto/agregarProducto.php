<?php
// agregarProducto.php
session_start();
require "administrador/funciones/conecta.php";
$con = conecta();

// Recibe variables
$idP  = $_POST['idP'];
$cant = $_POST['cant'];
$precio = $_POST['precio']; // Se añade el precio recibido por POST

$id_cliente = $_SESSION['usuario_id']; // Cambiado a 'usuario_id' para coincidir con el anterior
date_default_timezone_set('America/Mexico_City');
$sql = "SELECT * FROM pedidos WHERE id_cliente = $id_cliente AND status = 0";
$res = $con->query($sql);
$num = $res->num_rows;

if ($num == 0) {
    $fecha = date("Y-m-d H:i:s"); // Fecha actual en formato adecuado
    $sql = "INSERT INTO pedidos (fecha, id_cliente) VALUES ('$fecha', $id_cliente)";
    $res = $con->query($sql);
    $id_pedido = $con->insert_id; // Obtener el ID del nuevo pedido
} else {
    $row = $res->fetch_assoc();
    $id_pedido = $row['id'];
}

// Si la cantidad es mayor a 0, inserta o actualiza el producto en el pedido
if ($cant > 0) {
    // Verifica si ya se está pidiendo ese producto
    $sql = "SELECT * FROM pedidos_productos WHERE id_producto = $idP AND id_pedido = $id_pedido";
    $res = $con->query($sql);
    $num = $res->num_rows;

    if ($num == 0) {
        $sql = "INSERT INTO pedidos_productos (id_pedido, id_producto, cantidad, precio) VALUES ($id_pedido, $idP, $cant, $precio)";
    } else {
        $sql = "UPDATE pedidos_productos SET cantidad = cantidad + $cant WHERE id_producto = $idP AND id_pedido = $id_pedido";
    }
    $con->query($sql);
    header("Location: verPedido.php");
    exit();
} else {
    echo 0; // En caso de cantidad inválida
}

$con->close();
?>
