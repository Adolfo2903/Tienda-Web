<?php
//empleados_lista.php
require_once("administrador/funciones/conecta.php");

$con = conecta();
$sql = "SELECT * FROM productos WHERE status = 1";
$result = $con->query($sql);

if (!$result) {
    echo "Error en la consulta SQL: " . $con->error;
    exit; // Salir del script si hay un error en la consulta
}

$num = $result->num_rows;
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listado de Productos</title>
    <!-- Estilos CSS -->
    <style>
        /* Estilos CSS */
        body {
            font-family: Optima, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #e4fcd8;
        }
        
        header .img{
            max-width: 80px;
            height: auto;
            float: left;

        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #DAF7A6;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            
        }
        
        .row {
            display: flex;
            flex-wrap: wrap;
            margin: 0 -10px;
            justify-content: center;
        }
        
        .product {
            width: calc(33.33% - 20px);
            margin: 0 10px 20px;
            padding: 10px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .product-info {
            text-align: center;
        }

        .product-image img {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 5px;
        }

        .product-info h4 {
            margin-top: 10px;
            font-size: 20px;
        }

        .product-info p {
            margin-top: 5px;
            font-size: 15px;
        }

        .productos-actions {
            text-align: center;
        }

        .productos-actions button {
            background-color: #dc3545;
            color: #fff;
            border: none;
            padding: 5px 10px;
            border-radius: 3px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .productos-actions button:hover {
            background-color: #c82333;
        }

        .productos-actions #ver {
            background-color: #98b649;
            color: #fff;
            border: none;
            padding: 5px 10px;
            border-radius: 3px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .productos-actions #ver:hover {
            background-color: #323f0e;
        }
        .productos-actions #comprar {
            background-color:  #155b2a ;
            color: #fff;
            border: none;
            padding: 5px 10px;
            border-radius: 3px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .productos-actions #comprar:hover {
            background-color: #323f0e;
        }


        .back-to-add-button,
        .back-to-menu-button {
            background-color: #98b649;
            color: #fff;
            border: none;
            padding: 8px 16px;
            border-radius: 3px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            transition: background-color 0.3s;
        }

        .back-to-add-button:hover,
        .back-to-menu-button:hover {
            background-color: #323f0e;
        }

        h2 {
            color: #44782a;
        }

        /* Estilos para el encabezado */
        header {
            background-color: #e4fcd8;
            color: #44782a;
            padding: 10px 0;
            text-align: center;
        }
        header h1 {
            margin: 0;
            font-size: 26px;
        }
        /* Estilos para la barra de navegación */
        nav ul {
            list-style-type: none;
            padding: 0;
            text-align: center;
            margin-top: 20px;
        }
        nav ul li {
            display: inline;
            margin-right: 20px;
        }
        nav ul li a {
            text-decoration: none;
            color: #44782a;
            font-size:30px;
        }
        nav ul li a:hover {
            text-decoration: underline;
        }
        
    </style>
</head>
<body>

    <header>
        <div class="container">
        <img src="/Proyecto/administrador/logo/logoP.jpg" class="img">

            <nav>
                <ul>
                    <li><a href="administrador/funciones/bienvenidoClientes.php">Home</a></li>
                    <li><a href="productos_listaClientes.php">Productos</a></li>
                    <li><a href="contacto.php">Contacto</a></li>
                    <li><a href="verPedido.php">Carrito</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="container">
        <h2>Listado de Productos (<?php echo $num; ?>)</h2>
        
        <div class="row">
            <?php while ($row = $result->fetch_assoc()): ?>
                <div class="product">
                    <div class="product-info">
                        <div class="product-image">
                            <img src="/Proyecto/administrador/fotos_productos/<?php echo $row["archivo"];?>" alt="Imagen del producto">
                        </div>
                        <h4><?php echo $row["nombre"];?></h4>
                        <p><?php echo $row["descripcion"]; ?></p>
                        <p>Codigo: <?php echo $row["codigo"]; ?></p>
                        <p>$ <?php echo $row["costo"]; ?></p>
                    </div>
                    <div class="productos-actions">
                        <form action="agregarProducto.php" method="POST">
                            <input type="hidden" name="idP" value="<?php echo $row['id']; ?>">
                            <input type="hidden" name="precio" value="<?php echo $row['costo']; ?>">
                            <label for="cantidad">Cantidad:</label>
                            <input type="number" name="cant" value="1" min="1" max="99" required>
                            <button type="submit" id="comprar">Comprar</button>
                        </form>
                        <br><a href="administrador/funciones/ver_detalleProductoClientes.php?id=<?php echo $row["id"]; ?>" id="ver" class="button">Ver detalle</a>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    </div>
    <footer style="background-color: #e4fcd8; color: #44782a; text-align: center; padding: 20px;">
        <div>
            <p>Derechos Reservados &copy; <?php echo date("Y"); ?></p>
            <p><a href="#">Términos y Condiciones</a></p>
            <p>Redes Sociales: <a href="#">Facebook</a>, <a href="#">Twitter</a>, <a href="#">Instagram</a></p>
        </div>
    </footer>
</body>
</html>
