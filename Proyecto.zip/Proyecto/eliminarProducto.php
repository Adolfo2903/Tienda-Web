<?php
// eliminarProducto.php
session_start();
require "administrador/funciones/conecta.php";
$con = conecta();

$id_pedido_producto = $_POST['id_pedido_producto'];

$sql = "DELETE FROM pedidos_productos WHERE id = $id_pedido_producto";
$con->query($sql);

header("Location: verPedido.php");
?>
