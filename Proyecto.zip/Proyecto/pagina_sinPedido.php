<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sin Pedido</title>
    <style>
        body {
            font-family: Optima, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #e4fcd8;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        h2 {
            color: #44782a;
        }
        p {
            color: #666;
        }
        .back-link {
            background-color: #98b649;
            color: #fff;
            border: none;
            padding: 8px 16px;
            border-radius: 3px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            transition: background-color 0.3s;
        }
        .back-link:hover {
            background-color: #323f0e;
        }
    </style></head>
<body>
    <div class="container">
        <h2>No tienes ningún pedido activo</h2>
        <p>Por favor, realiza un pedido antes de acceder a esta página.</p>
        <p><a href="productos_listaClientes.php" class="back-link">Volver a la lista de productos</a></p>
    </div>
</body>
</html>
