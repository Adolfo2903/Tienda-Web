<html lang="es">
<head>
    <title>Registro de Cliente</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <style>
        /* Estilos CSS */
        body {
            font-family: Optima, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #e4fcd8;
        }
        form {
            max-width: 400px;
            margin: 20px auto;
            padding: 20px;
            background-color: #DAF7A6;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        label {
            font-weight: bold;
        }
        input[type="text"],
        input[type="email"],
        input[type="file"] {
            width: 100%;
            padding: 10px;
            margin: 5px 0 20px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }
        input[type="submit"] {
            background-color: #98b649;
            color: #fff;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #323f0e;
        }
        .error-message {
            color: red;
            font-size: 14px;
        }
        .centrado {
            text-align: center;
        }
        h2 {
            color: #44782a;
        }
    </style>
</head>
<body>
    <form action="procesar_registroClientes.php" method="POST" enctype="multipart/form-data">
        <h2>Registro de Cliente</h2>
        <label for="nombre">Nombre:<span style="color: red;">*</span></label><br>
        <input type="text" id="nombre" name="nombre" placeholder="Ingresa Nombre" required><br>
        
        <label for="apellidos">Apellidos:<span style="color: red;">*</span></label><br>
        <input type="text" id="apellidos" name="apellidos" placeholder="Ingresa Apellidos" required><br>
        
        <label for="correo">Correo:<span style="color: red;">*</span></label><br>
        <input type="email" id="correo" name="correo" placeholder="Ingresa Correo" required>
        <span class="error-message" id="error-correo"></span><br>

        <label for="password">Contraseña:<span style="color: red;">*</span></label><br>
        <input type="text" id="password" name="password" placeholder="Ingresa Contraseña" required><br>

        <div class="centrado">
            <input type="submit" value="Registrar">
        </div>
    </form>

    <script>
        $(document).ready(function() {
            $('#correo').blur(function() {
                var correo = $(this).val();
                $.ajax({
                    url: 'administrador/funciones/verificar_correoClientes.php',
                    type: 'post',
                    data: { correo: correo },
                    success: function(response) {
                        if (response === 'existe') {
                            $('#error-correo').text('El correo ' + correo + ' ya existe.');
                            $('input[type="submit"]').attr('disabled', true);
                        } else {
                            $('#error-correo').text('');
                            $('input[type="submit"]').removeAttr('disabled');
                        }
                    }
                });
            });
        });
    </script>

<footer style="background-color: #e4fcd8; color: #44782a; text-align: center; padding: 20px;">
        <div>
            <p>Derechos Reservados &copy; <?php echo date("Y"); ?></p>
            <p><a href="#">Términos y Condiciones</a></p>
            <p>Redes Sociales: <a href="#">Facebook</a>, <a href="#">Twitter</a>, <a href="#">Instagram</a></p>
        </div>
    </footer>
</body>
</html>
