<?php
// actualizarCantidad.php
session_start();
require "administrador/funciones/conecta.php";
$con = conecta();

$id_pedido_producto = $_POST['id_pedido_producto'];
$cantidad = $_POST['cantidad'];

// Obtener ID del producto y el ID del pedido
$sql = "SELECT id_producto, id_pedido FROM pedidos_productos WHERE id = $id_pedido_producto";
$res = $con->query($sql);
$pedido_producto = $res->fetch_assoc();
$id_producto = $pedido_producto['id_producto'];
$id_pedido = $pedido_producto['id_pedido'];

// Obtener stock del producto
$sql = "SELECT stock FROM productos WHERE id = $id_producto";
$res = $con->query($sql);
$producto = $res->fetch_assoc();
$stock = $producto['stock'];

if ($cantidad > 0 && $cantidad <= $stock) {
    $sql = "UPDATE pedidos_productos SET cantidad = $cantidad WHERE id = $id_pedido_producto";
    $con->query($sql);
} else {
    echo "Cantidad inválida o supera el stock disponible.";
}

header("Location: verPedido.php");
?>
