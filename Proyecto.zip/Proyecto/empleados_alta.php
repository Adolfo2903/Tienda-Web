<html>
<head>
    <title>Registro de Empleado</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <style>
        
        /* Estilos CSS */
        body {
            font-family: Optima, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #e4fcd8;
        }
        form {
            max-width: 1200px;
            margin: 0px auto;
            padding: 20px;
            background-color: #DAF7A6;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        label {
            font-weight: bold;
        }
        input[type="text"],
        input[type="email"] {
            width: 40%;
            padding: 10px;
            margin: 5px 0 20px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }


            

        
        input[type="submit"] {
            background-color: #98b649;
            color: #fff;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #323f0e;
        }
        .error-message {
            color: red;
            font-size: 14px;
        }

        .centrado {
        text-align: center;
        }

        #nombre {

            background-color: #eefae8 ; /* Color de fondo del botón */
        }

        #apellidos {

        background-color: #eefae8 ; /* Color de fondo del botón */
        }


        #correo {

        background-color: #eefae8 ; /* Color de fondo del botón */
        }

        #password {

        background-color: #eefae8 ; /* Color de fondo del botón */
        }



        .back-to-menu-button {
            background-color: #98b649; /* Color de fondo del botón */
            color: #fff; /* Color del texto del botón */
            border: none; /* Quitamos el borde del botón */
            padding: 8px 16px; /* Espaciado interno del botón */
            border-radius: 3px; /* Borde redondeado */
            cursor: pointer; /* Cambiamos el cursor al pasar sobre el botón */
            text-decoration: none; /* Quitamos el subrayado del enlace */
            display: inline-block; /* Para que el enlace se comporte como un bloque */
            transition: background-color 0.3s; /* Efecto de transición suave */
        }

        .back-to-menu-button:hover {
            background-color: #323f0e; /* Cambio de color al pasar el cursor sobre el botón */
        }

        .back-to-list-button {
            background-color: #98b649; /* Color de fondo del botón */
            color: #fff; /* Color del texto del botón */
            border: none; /* Quitamos el borde del botón */
            padding: 8px 16px; /* Espaciado interno del botón */
            border-radius: 3px; /* Borde redondeado */
            cursor: pointer; /* Cambiamos el cursor al pasar sobre el botón */
            text-decoration: none; /* Quitamos el subrayado del enlace */
            display: inline-block; /* Para que el enlace se comporte como un bloque */
            transition: background-color 0.3s; /* Efecto de transición suave */
        }

        .back-to-list-button:hover {
            background-color: #323f0e; /* Cambio de color al pasar el cursor sobre el botón */
        }


        h2{
            color:  #44782a ;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #DAF7A6;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            
        }
        
        /* Estilos para el encabezado */
        header {
            background-color: #e4fcd8;
            color: #44782a;
            padding: 10px 0;
            text-align: center;
        }
        header h1 {
            margin: 0;
            font-size: 26px;
        }
        /* Estilos para la barra de navegación */
        nav ul {
            list-style-type: none;
            padding: 0;
            text-align: center;
            margin-top: 20px;
        }
        nav ul li {
            display: inline;
            margin-right: 20px;
        }
        nav ul li a {
            text-decoration: none;
            color: #44782a;
            font-size:30px;
        }
        nav ul li a:hover {
            text-decoration: underline;
        }
        header .img{
            max-width: 80px;
            height: auto;
            float: left;

        }

    </style>
</head>
<body>

    <header>
        <div class="container">
        <img src="/Proyecto/administrador/logo/logoP.jpg" class="img">

            <nav>
                <ul>
                    <li><a href="administrador/funciones/bienvenido.php">Home</a></li>
                    <li><a href="administrador/funciones/inicio.php">Empleados</a></li>
                    <li><a href="productos_lista.php">Productos</a></li>
                    <li><a href="promociones_lista.php">Promociones</a></li>
                    <li><a href="productosCerrados.php">Pedidos</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <form action="procesar_registro.php" method="POST" enctype="multipart/form-data">
        <h2>Registro de Empleado</h2>
        <!--<a href="empleados_lista.php" class="back-to-list-button">Regresar al Listado</a><br><br>-->

        <label for="nombre">Nombre:<span style="color: red;">*</span></label><br>
        <input type="text" id="nombre" name="nombre" placeholder="Ingresa Nombre" required><br>
        
        <label for="apellidos">Apellidos:<span style="color: red;">*</span></label><br>
        <input type="text" id="apellidos" name="apellidos" placeholder="Ingresa Apellidos" required><br>
        
        <label for="correo">Correo:<span style="color: red;">*</span></label><br>
        <input type="email" id="correo" name="correo" placeholder="Ingresa Correo" required>
        <span class="error-message" id="error-correo"></span><br>

        <label for="pass">Contraseña:<span style="color: red;">*</span></label><br>
        <input type="text" id="password" name="password" placeholder="Ingresa Contraseña" required><br>

        <label for="foto">Foto:</label><br>
        <input type="file" id="foto" name="foto" accept="image/*" required>
        <span class="error-message" id="error-foto"></span><br><br>

        <label for="rol">Rol:</label><br>
        <select type="text" id="rol" name="rol">
            <option value="0">Selecciona</option>
            <option value="Gerente">Gerente</option>
            <option value="Ejecutivo">Ejecutivo</option>
        </select><br><br>

        <!--<a href="administrador/funciones/inicio.php" class="back-to-menu-button">Regresar al Menú</a><br><br>-->


        <div class="centrado">
            <input type="submit" value="Registrar">
        </div>

    </form>

    <script>
        $(document).ready(function() {
            $('#correo').blur(function() {
                var correo = $(this).val();
                $.ajax({
                    url: 'administrador/funciones/verificar_correo.php',
                    type: 'post',
                    data: { correo: correo },
                    success: function(response) {
                        if (response === 'existe') {
                            $('#error-correo').text('El correo ' + correo + ' ya existe.');
                            $('#error-correo').addClass('error-correo-existente');
                            $('input[type="submit"]').attr('disabled', true);
                        } else {
                            $('#error-correo').text('');
                            $('#error-correo').removeClass('error-correo-existente');
                            $('input[type="submit"]').removeAttr('disabled');
                        }
                    }
                });
            });
        });
    </script>

<footer style="background-color: #e4fcd8; color: #44782a; text-align: center; padding: 20px;">
        <div>
            <p>Derechos Reservados &copy; <?php echo date("Y"); ?></p>
            <p><a href="#">Términos y Condiciones</a></p>
            <p>Redes Sociales: <a href="#">Facebook</a>, <a href="#">Twitter</a>, <a href="#">Instagram</a></p>
        </div>
    </footer>

</body>
</html>