<?php
//Enviar_correo.php
// Verifica que el formulario se haya enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtén los datos del formulario y límpialos
    $nombre = htmlspecialchars($_POST['nombre']);
    $correo = htmlspecialchars($_POST['correo']);
    $telefono = htmlspecialchars($_POST['telefono']);
    $comentarios = htmlspecialchars($_POST['comentarios']);

    // Dirección de correo del destinatario
    $destinatario = "dofitojrglez@gmail.com";
    
    // Asunto del correo
    $asunto = "Nuevo mensaje de contacto desde el formulario";

    // Cuerpo del mensaje
    $mensaje = "Nombre: $nombre\n";
    $mensaje .= "Correo Electrónico: $correo\n";
    $mensaje .= "Teléfono: $telefono\n";
    $mensaje .= "Comentarios:\n$comentarios";

    // Cabeceras del correo
    $cabeceras = "From: adolfglez2904@gmail.com\r\n"; // 
    $cabeceras .= "Reply-To: $correo\r\n";
    $cabeceras .= "X-Mailer: PHP/" . phpversion();

    // Envía el correo
    if (mail($destinatario, $asunto, $mensaje, $cabeceras)) {
        echo '<script>alert("Correo enviado exitosamente");</script>';
        echo '<script>window.location.href = "contacto.php";</script>';
    } else {
        echo '<script>alert("Error al enviar el correo. Por favor, inténtelo más tarde.");</script>';
        echo '<script>window.location.href = "contacto.php";</script>';
    }
} else {
    echo '<script>alert("Acceso no autorizado.");</script>';
    echo '<script>window.location.href = "contacto.php";</script>';
}
?>
