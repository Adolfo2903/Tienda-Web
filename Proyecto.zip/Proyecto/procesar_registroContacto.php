<?php
require("administrador/funciones/conecta.php");

// Verificar si se enviaron datos mediante el método POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verificar la existencia de datos y validarlos
    if (isset($_POST["nombre"]) && isset($_POST["correo"]) && isset($_POST["telefono"]) && isset($_POST["comentarios"])) {
        
        // Recoger los datos del formulario
        $nombre = trim($_POST["nombre"]);
        $correo = trim($_POST["correo"]);
        $telefono = trim($_POST["telefono"]);
        $comentarios = trim($_POST["comentarios"]);

        // Crear una conexión a la base de datos
        $con = conecta();

        // Preparar la consulta SQL para insertar un nuevo contacto
        $sql = "INSERT INTO contacto (nombre, correo, telefono, comentarios) VALUES (?, ?, ?, ?)";

        // Preparar la declaración
        $stmt = $con->prepare($sql);

        // Vincular los parámetros
        $stmt->bind_param("ssss", $nombre, $correo, $telefono, $comentarios);

        // Ejecutar la consulta
        if ($stmt->execute()) {
            // Redireccionar a una página de confirmación
            header("Location: administrador/funciones/confirmacion_contacto.php");
            exit();
        } else {
            // Mostrar un mensaje de error si la inserción falla
            echo "Error al registrar el contacto: " . $con->error;
        }

        // Cerrar la conexión
        $con->close();
    } else {
        // Mostrar un mensaje de error si faltan datos
        echo "Por favor, complete todos los campos obligatorios.";
    }
}
?>
