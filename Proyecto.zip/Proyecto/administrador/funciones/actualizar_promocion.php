<?php
require_once("conecta.php");

$con = conecta();

// Verificar si se enviaron datos mediante el método POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verificar la existencia de datos y validarlos
    if (isset($_POST["id"]) && isset($_POST["nombre"])) {
        $id = $_POST["id"];
        $nombre = trim($_POST["nombre"]);

        // Preparar la consulta SQL para actualizar el producto
        $sql = "UPDATE promociones SET nombre=? WHERE id=?";

        // Preparar la declaración
        $stmt = $con->prepare($sql);

        // Vincular los parámetros
        $stmt->bind_param("si", $nombre, $id);

        // Ejecutar la consulta
        if ($stmt->execute()) {
            // Redireccionar a la página de lista de productos después de la actualización
            header("Location: /Proyecto/promociones_lista.php");
            exit();
        } else {
            // Mostrar un mensaje de error si la actualización falla
            echo "Error al actualizar la promocion: " . $con->error;
        }

        // Cerrar la conexión
        $con->close();
    } else {
        // Mostrar un mensaje de error si faltan datos
        echo "Por favor, complete todos los campos obligatorios.";
    }
}
?>
