<?php
// funciones/eliminar_promocion.php
require_once("conecta.php");

function eliminar_promocion($id) {
    // Conectar a la base de datos
    $con = conecta();

    // Preparar la consulta SQL para eliminar el producto
    $sql = "UPDATE promociones SET status = 0 WHERE id = ?";
    // Preparar la declaración
    $stmt = $con->prepare($sql);

    // Vincular el parámetro
    $stmt->bind_param("i", $id);

    // Ejecutar la consulta
    if ($stmt->execute()) {
        // Si se elimina correctamente, redirigir a la página de lista
        header("Location: /Proyecto/promociones_lista.php");
        exit(); // Salir del script después de la redirección
    } else {
        // Si hay un error, mostrar el mensaje de error
        echo "Error al eliminar el promocion: " . $stmt->error;
    }

    // Cerrar la conexión y la declaración
    $stmt->close();
    $con->close();
}

// Verificar si se ha enviado el ID del producto a eliminar
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['id'])) {
        $id = $_POST['id'];
        eliminar_promocion($id);
    } else {
        echo "No se recibió el ID de la promocion a eliminar.";
    }
}
?>
