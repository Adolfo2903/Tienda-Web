<?php


// Función para verificar si hay una sesión activa
function verificar_sesion() {
    // Iniciar la sesión si no está iniciada
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }

    // Verificar si NO hay una sesión activa
    if (!isset($_SESSION['usuario'])) {
        // Si no hay una sesión activa, redirigir al usuario al formulario de inicio de sesión
        header('Location: index.php');
        exit();
    }
}

?>
