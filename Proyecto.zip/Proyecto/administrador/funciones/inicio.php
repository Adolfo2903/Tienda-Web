<?php
// Verificar si hay una sesión activa
/*
Adolfo De Jesus Gonzalez Lopez
219540979
*/
require_once("conecta.php");
$con = conecta();

session_start();

// Verificar si hay una sesión activa
if (!isset($_SESSION['usuario'])) {
    // Si no hay sesión activa, redirigir al formulario de inicio de sesión
    header("Location: index.php");
    exit; // Agregar esta línea para evitar que se procese más código después de la redirección
}

$usuario = $_SESSION['usuario'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu Empleados</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <style>
        /* Estilos CSS */
        /* index.php */

        body {
            font-family: Optima, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #e4fcd8;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-colo r: #DAF7A6;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        label {
            font-weight: bold;
        }
        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            margin: 5px 0 20px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }
        h2 {
            color: #44782a;
        }
        button {
            background-color: #98b649;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 15px 30px;
            margin: 10px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #323f0e;
        }

        /* Estilos para el encabezado */
        header {
            background-color: #e4fcd8;
            color: #44782a;
            padding: 10px 0;
            text-align: center;
        }
        header h1 {
            margin: 0;
            font-size: 26px;
        }
        /* Estilos para la barra de navegación */
        nav ul {
            list-style-type: none;
            padding: 0;
            text-align: center;
            margin-top: 20px;
        }
        nav ul li {
            display: inline;
            margin-right: 20px;
        }
        nav ul li a {
            text-decoration: none;
            color: #44782a;
            font-size:30px;
        }
        nav ul li a:hover {
            text-decoration: underline;
        }
        header .img{
            max-width: 80px;
            height: auto;
            float: left;

        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #DAF7A6;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            
        }
        
    </style>
    <script>
        $(document).ready(function(){
            $(".añadir").click(function(){
                window.location.href = "/Proyecto/empleados_alta.php";            });
            $(".lista").click(function(){
                window.location.href = "/Proyecto/empleados_lista.php";                                   });
        });
    </script>
</head>
<body>

    <header>
        <div class="container">
        <img src="/Proyecto/administrador/logo/logoP.jpg" class="img">

            <nav>
                <ul>
                    <li><a href="bienvenido.php">Home</a></li>
                    <li><a href="inicio.php">Empleados</a></li>
                    <li><a href="/Proyecto/productos_lista.php">Productos</a></li>
                    <li><a href="/Proyecto/promociones_lista.php">Promociones</a></li>
                    <li><a href="/Proyecto/productosCerrados.php">Pedidos</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="container">
        <h2>Menú Empleados</h2>
        <button class="añadir">Anadir empleado</button>
        <button class="lista">Lista empleado</button>

    </div>

    <footer style="background-color: #e4fcd8; color: #44782a; text-align: center; padding: 20px;">
        <div>
            <p>Derechos Reservados &copy; <?php echo date("Y"); ?></p>
            <p><a href="#">Términos y Condiciones</a></p>
            <p>Redes Sociales: <a href="#">Facebook</a>, <a href="#">Twitter</a>, <a href="#">Instagram</a></p>
        </div>
    </footer>
    
</body>
</html>
