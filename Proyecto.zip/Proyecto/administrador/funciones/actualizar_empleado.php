<?php
require_once("conecta.php");

$con = conecta();

// Definir el directorio de destino de las fotos de los empleados
$directorio_destino = "/Proyecto/administrador/fotos_empleados/";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["id"])) {
    $id = $_POST["id"];
    $nombre = $_POST["nombre"];
    $apellidos = $_POST["apellidos"];
    $correo = $_POST["correo"];
    $rol = $_POST["rol"];

    // Verificar si se proporciona una nueva contraseña
    if (!empty($_POST["password"])) {
        $password = $_POST["password"];
        // Si se proporciona una nueva contraseña, se actualiza en la base de datos
        $sql = "UPDATE empleados SET nombre='$nombre', apellidos='$apellidos', correo='$correo', password='$password', rol='$rol'";
    } else {
        // Si no se proporciona una nueva contraseña, se excluye de la actualización
        $sql = "UPDATE empleados SET nombre='$nombre', apellidos='$apellidos', correo='$correo', rol='$rol'";
    }

    // Verificar si se proporcionó una nueva foto
    if (!empty($_FILES["foto"]["name"])) {
        // Nombre del archivo en el servidor
        $nombre_archivo_real = $_FILES["foto"]["name"];
        // Nombre encriptado para el almacenamiento
        $nombre_archivo_encriptado = md5(uniqid(rand(), true)) . '.' . pathinfo($nombre_archivo_real, PATHINFO_EXTENSION);
        // Ruta donde se almacenará el archivo
        $ruta_archivo_destino = $_SERVER['DOCUMENT_ROOT'] . $directorio_destino . $nombre_archivo_encriptado;
        
        // Mover el archivo cargado al directorio de destino
        if (move_uploaded_file($_FILES["foto"]["tmp_name"], $ruta_archivo_destino)) {
            // Actualizar el nombre de la foto en la base de datos
            $sql .= ", foto_nombre_real='$nombre_archivo_real', foto_nombre_encriptado='$nombre_archivo_encriptado'";
        } else {
            echo "Error al cargar la foto.";
            exit();
        }
    }
    
    // Agregar la condición WHERE para actualizar solo el empleado seleccionado
    $sql .= " WHERE id='$id'";
    
    if ($con->query($sql) === TRUE) {
        // Redireccionar a la página de lista de empleados después de la actualización
        header("Location: /Proyecto/empleados_lista.php");
        exit();
    } else {
        echo "Error al actualizar el empleado: " . $con->error;
    }
} else {
    // Redireccionar si no se envían datos POST o no se proporciona el ID del empleado
    header("Location: /Proyecto/empleados_lista.php");
    exit();
}
?>
