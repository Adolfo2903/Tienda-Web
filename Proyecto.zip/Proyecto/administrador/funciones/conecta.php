<?php
//conecta.php

// Definir las constantes de conexión
define("HOST", "localhost"); // Nombre del servidor de la base de datos
define("BD", "empresa01"); // Nombre de la base de datos
define("USER_BD", "root"); // Nombre de usuario de la base de datos
define("PASS_BD", ""); // Contraseña de la base de datos

// Función para conectar a la base de datos
function conecta() {
    // Crear una nueva conexión a la base de datos
    $con = new mysqli(HOST, USER_BD, PASS_BD, BD);

    // Verificar si hay errores de conexión
    if ($con->connect_error) {
        // Mostrar un mensaje de error si la conexión falla
        die("Error al conectar con la base de datos: " . $con->connect_error);
    }

    // Devolver la conexión
    return $con;
}
?>
