<?php
// Verificar si hay una sesión activa
/*
Adolfo De Jesus Gonzalez Lopez
219540979
*/
require_once("conecta.php");
$con = conecta();

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <style>
        /* Estilos CSS */
        /* index.php */

        body {
            font-family: Optima, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #e4fcd8;
        }
        .container {
            max-width: 800px;
            margin: 200px auto; /* Cambio en esta línea */
            padding: 20px;
            background-color: #DAF7A6;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        label {
            font-weight: bold;
        }
        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            margin: 5px 0 20px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }
        h2 {
            color: #44782a;
            font-size: 50px;

        }
        button {
            background-color: #98b649;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 15px 30px;
            margin: 10px;
            cursor: pointer;
            font-size: 26px;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #323f0e;
        }
    </style>
    <script>
        $(document).ready(function(){
            $(".cliente").click(function(){
                window.location.href = "indexClientes.php";            });
            $(".empleado").click(function(){
                window.location.href = "index.php";                                   });
            /*$(".regresar").click(function(){
                window.location.href = "bienvenido.php";                                   });*/
        });
    </script>
</head>
<body>
    <div class="container">
        <h2>Ingreso</h2>
        <button class="cliente">Iniciar como Clientes</button>
        <button class="empleado">Iniciar como Empleado</button>
        <!--<button class="regresar">Regresar</button>-->

    </div>

    <footer style="background-color: #e4fcd8; color: #44782a; text-align: center; padding: 20px;">
        <div>
            <p>Derechos Reservados &copy; <?php echo date("Y"); ?></p>
            <p><a href="#">Términos y Condiciones</a></p>
            <p>Redes Sociales: <a href="#">Facebook</a>, <a href="#">Twitter</a>, <a href="#">Instagram</a></p>
        </div>
    </footer>
    
</body>
</html>
