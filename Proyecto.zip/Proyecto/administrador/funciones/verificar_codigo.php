<?php
    // Conectar a la base de datos

require_once("conecta.php");


function verificar_codigo_existente($codigo) {
    // Conectar a la base de datos
    $con = conecta();

    // Preparar la consulta SQL para verificar si el correo existe
    $stmt = $con->prepare("SELECT codigo FROM productos WHERE codigo = ?");
    $stmt->bind_param("s", $codigo);
    $stmt->execute();
    $stmt->store_result();
    $num_rows = $stmt->num_rows;
    $stmt->close();
    $con->close();
    
    // Devolver el resultado
    return $num_rows > 0; // Devuelve true si el codigo existe, false si no existe
}

// Verificar si se ha enviado el correo a comprobar
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['codigo'])) {
        $codigo = $_POST['codigo'];
        if (verificar_codigo_existente($codigo)) {
            echo 'existe';
        } else {
            echo 'no_existe';
        }
    } else {
        echo "No se recibió el codigo a verificar.";
    }
}

?>