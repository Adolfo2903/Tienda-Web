<?php
// Inicio
/*
Adolfo De Jesus Gonzalez Lopez
219540979
Programacion para internet 

*/
require_once("conecta.php");
$con = conecta();
session_start();

// Verificar si hay una sesión activa
if (!isset($_SESSION['usuario'])) {
    // Si no hay sesión activa, redirigir al formulario de inicio de sesión
    header("Location: indexClientes.php");
    exit; // Agregar esta línea para evitar que se procese más código después de la redirección
}
$usuario = $_SESSION['usuario'];
$id = $_SESSION['usuario_id'];

// Carpeta donde se almacenan las imágenes
$ruta_imagenes ='../../administrador/fotos_promociones/';

// Obtener la lista de imágenes disponibles
$imagenes = glob($ruta_imagenes . '*.{jpg,png,gif}', GLOB_BRACE);

// Seleccionar una imagen aleatoria
$imagen_aleatoria = $imagenes[array_rand($imagenes)];

$sql = "SELECT * FROM productos WHERE status = 1 ORDER BY RAND() LIMIT 4";
$result = $con->query($sql);
?>
 
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bienvenido</title>
    <style>
        /* Estilos generales */
        body {
            font-family: Optima, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #DAF7A6;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;

        }
        /* Estilos para el encabezado */
        header {
            background-color: #e4fcd8;
            color: #44782a;
            padding: 10px 0;
            text-align: center;
        }
        header h1 {
            margin: 0;
            font-size: 26px;
        }
        /* Estilos para la barra de navegación */
        nav ul {
            list-style-type: none;
            padding: 0;
            text-align: center;
            margin-top: 20px;
        }
        nav ul li {
            display: inline;
            margin-right: 20px;
        }
        nav ul li a {
            text-decoration: none;
            color: #44782a;
            font-size:30px;
        }
        nav ul li a:hover {
            text-decoration: underline;
        }

        header .img{
            max-width: 110px;
            height: auto;
            float: left;

        }
        /* Estilos para la imagen aleatoria */
        .image_container {
            text-align: center;
            margin-top: 0px;
        }
        .image_container img {
            width: 500px;
            height: 350px;
            border-radius: 10px;
            box-shadow: 0px 0px 20px 0px rgba(0, 0, 0, 0.5);
        
        }
        /* Estilos para los productos */
        .container_productos {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            align-items: center;
            margin-top: 10px;
            height: 250px;
        }
        .producto {
            width: 200px;
            max-height: auto;
            margin: 20px;
            text-align: center;
            background-color: white;
            padding: 10px;
            border-radius: 10px;
            box-shadow: 0px 0px 20px 0px rgba(0, 0, 0, 0.1);
        }
        .producto img {
            width: 150px;
            height: 150px;
            object-fit: cover;
            border-radius: 10px;
        }
        .producto h4 {
            margin-top: 10px;
            font-size: 20px;
        }
        .producto p {
            margin-top: 5px;
            font-size: 15px;
        }


        .producto #comprar {
            background-color:  #155b2a ;
            color: #fff;
            border: none;
            padding: 5px 10px;
            border-radius: 3px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .producto #comprar:hover {
            background-color: #323f0e;
        }

    </style>
</head>
<body>
    <header>
        <img src="/Proyecto/administrador/logo/logoP.jpg" class="img">
        <div class="container">
            <nav>
                <ul>
                    <li><a href="bienvenidoClientes.php">Home</a></li>
                    <li><a href="/Proyecto/productos_listaClientes.php">Productos</a></li>
                    <li><a href="/Proyecto/contacto.php">Contacto</a></li>
                    <li><a href="/Proyecto/verPedido.php">Carrito</a></li>
                    <li><a href="cerrar_sesion.php">Salir</a></li>
                </ul>
            </nav>
            <h1>¡¡Bienvenid@, <?php echo $usuario; ?>!!</h1>
            <p>Tu ID de usuario es: <?php echo $id; ?></p>        </div>
    </header>

    <div class="container">
        <!-- Mostrar imagen aleatoria -->
        <div class="image_container">
            <img src="<?php echo $imagen_aleatoria; ?>" alt="Imagen aleatoria">
        </div>

        <!-- Mostrar productos -->
        <div class="container_productos">
            <?php while ($row = $result->fetch_assoc()): ?>
                <div class="producto">
                    <img src="/Proyecto/administrador/fotos_productos/<?php echo $row["archivo"];?>" alt="Imagen del producto">
                    <h4><a href="ver_detalleProductoClientes.php?id=<?php echo $row["id"]; ?>"><?php echo $row["nombre"];?></a></h4>
                    <p><?php echo $row["descripcion"]; ?></p>
                    <p>Precio: <?php echo $row["costo"]; ?></p>
                    <div class="productos-actions">
                        <form action="/Proyecto/agregarProducto.php" method="POST">
                            <input type="hidden" name="idP" value="<?php echo $row['id']; ?>">
                            <input type="hidden" name="precio" value="<?php echo $row['costo']; ?>">
                            <input type="number" name="cant" value="1" min="1" max="99" required>
                            <button type="submit" id="comprar">Comprar</button>
                        </form>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    </div>

    <br><br><br><br<br><br><br><br><footer style="background-color: #e4fcd8; color: #44782a;text-align: center; padding: 20px;">
        <div>
            <p>Derechos Reservados &copy; <?php echo date("Y"); ?></p>
            <p><a href="#">Términos y Condiciones</a></p>
            <p>Redes Sociales: <a href="#">Facebook</a>, <a href="#">Twitter</a>, <a href="#">Instagram</a></p>
        </div>
    </footer>
    
</body>
</html>
