<html>
<head>
    <title>Inicio de Sesión</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <style>
        body {
            font-family: Optima, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #e4fcd8;
        }
        form {
            max-width: 400px;
            margin: 20px auto;
            padding: 20px;
            background-color: #DAF7A6;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        label {
            font-weight: bold;
        }
        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            margin: 5px 0 20px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }
        .button-container {
            display: flex;
            justify-content: space-between;
        }
        input[type="submit"] {
            background-color: #98b649;
            color: #fff;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            cursor: pointer;
            flex: 1;
            margin-right: 10px;
        }
        input[type="submit"]:hover {
            background-color: #323f0e;
        }
        #mensaje {
            color: red;
            font-size: 14px;
        }
        #password {
            background-color: #eefae8;
        }
        #usuario {
            background-color: #eefae8;
        }
        h2 {
            color: #44782a;
        }
        button {
            background-color: #98b649;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
            flex: 1;
        }
        button:hover {
            background-color: #323f0e;
        }
    </style>
    <script>
        $(document).ready(function(){
            $(".regresar").click(function(){
                window.location.href = "menu_inicio.php";
            });
        });
    </script>
</head>
<body>
    <form id="loginForm" action="#" method="POST">
        <h2>Iniciar Sesión</h2>
        <label for="usuario">Usuario (Correo electrónico):</label><br>
        <input type="text" id="usuario" name="usuario" required><br>
        <label for="password">Contraseña:</label><br>
        <input type="password" id="password" name="password" required><br>
        <div class="button-container">
            <input type="submit" value="Iniciar Sesión">
            <button class="regresar">Regresar</button>
        </div>
        <div id="mensaje"></div>
    </form>
    <script>
        $(document).ready(function() {
            $('#loginForm').submit(function(event) {
                event.preventDefault(); // Evitar el envío del formulario por defecto

                // Obtener los valores de usuario y contraseña
                var usuario = $('#usuario').val();
                var password = $('#password').val();

                // Validar que los campos no estén vacíos
                if (usuario === '' || password === '') {
                    $('#mensaje').text('Por favor, completa todos los campos.');
                } else {
                    // Realizar la petición AJAX para verificar el usuario
                    $.ajax({
                        url: 'verificar_usuario.php',
                        type: 'POST',
                        data: { usuario: usuario, password: password },
                        success: function(response) {
                            if (response === 'existe') {
                                // Si el usuario existe, redirigir a la página de bienvenida.php
                                window.location.href = 'bienvenido.php';
                            } else {
                                // Si el usuario no existe, mostrar un mensaje de error
                                $('#mensaje').text('Usuario o contraseña incorrectos.');
                            }
                        }
                    });
                }
            });
        });
    </script>

    <footer style="background-color: #e4fcd8; color: #44782a; text-align: center; padding: 20px;">
        <div>
            <p>Derechos Reservados &copy; <?php echo date("Y"); ?></p>
            <p><a href="#">Términos y Condiciones</a></p>
            <p>Redes Sociales: <a href="#">Facebook</a>, <a href="#">Twitter</a>, <a href="#">Instagram</a></p>
        </div>
    </footer>

</body>
</html>
