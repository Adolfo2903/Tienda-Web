<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Promocion</title>
    <style>
        body {
            font-family: Optima, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #e4fcd8;
        }
        header {
            background-color: #e4fcd8;
            color: #44782a;
            padding: 10px 0;
            text-align: center;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #DAF7A6;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            
        }
        header .img{
            max-width: 80px;
            height: auto;
            float: left;

        }
        nav ul {
            list-style-type: none;
            padding: 0;
            text-align: center;
            margin-top: 20px;
        }
        nav ul li {
            display: inline;
            margin-right: 20px;
        }
        nav ul li a {
            text-decoration: none;
            color: #44782a;
            font-size:30px;
        }
        form {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #DAF7A6;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        label {
            font-weight: bold;
            font-size: 18px;
        }
        input[type="text"],
        input[type="email"] {
            width: 40%;
            padding: 12px;
            margin: 10px 0 25px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }
        input[type="submit"] {
            background-color: #98b649;
            color: #fff;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #323f0e;
        }
        .error-message {
            color: red;
            font-size: 16px;
            text-align: center;
        }
        .centrado {
            text-align: center;
        }
        .back-to-list-button {
            background-color: #98b649;
            color: #fff;
            border: none;
            padding: 12px 24px;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            transition: background-color 0.3s;
            font-size: 17px;
        }
        .back-to-list-button:hover {
            background-color: #323f0e;
        }
        #nombre {
            background-color: #eefae8;
        }
        h2 {
            color: #44782a;
            text-align: center;
            font-size: 24px;
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <img src="/Proyecto/administrador/logo/logoP.jpg" class="img" alt="Logo">
            <nav>
                <ul>
                <li><a href="bienvenido.php">Home</a></li>
                    <li><a href="inicio.php">Empleados</a></li>
                    <li><a href="/Proyecto/productos_lista.php">Productos</a></li>
                    <li><a href="/Proyecto/promociones_lista.php">Promociones</a></li>
                    <li><a href="/Proyecto/productosCerrados.php">Pedidos</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <?php
    require_once("conecta.php");
    $con = conecta();
    if(isset($_GET['id']) && is_numeric($_GET['id'])) {
        $id = $_GET['id'];
        $sql = "SELECT * FROM promociones WHERE id = $id";
        $result = $con->query($sql);
        if($result && $result->num_rows > 0) {
            $promocion = $result->fetch_assoc();
    ?>
    <form action="actualizar_promocion.php" method="POST">
        <h2>Editar Promocion</h2>
        <input type="hidden" name="id" value="<?php echo $promocion['id']; ?>">
        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" value="<?php echo $promocion['nombre']; ?>"><br>
        <input type="submit" value="Guardar cambios"><br>
    </form>
    <?php
        } else {
            echo "<p class='error-message'>La promocion no existe.</p>";
        }
    } else {
        echo "<p class='error-message'>ID de la promocion no válido.</p>";
    }
    ?>

    <footer style="background-color: #e4fcd8; color: #44782a; text-align: center; padding: 20px;">
        <div>
            <p>Derechos Reservados &copy; <?php echo date("Y"); ?></p>
            <p><a href="#">Términos y Condiciones</a></p>
            <p>Redes Sociales: <a href="#">Facebook</a>, <a href="#">Twitter</a>, <a href="#">Instagram</a></p>
        </div>
    </footer>
</body>
</html>
