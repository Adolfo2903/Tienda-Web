<?php
// funciones/eliminar_usuario.php
require_once("conecta.php");

function actualizar_estado_usuario($id) {
    // Conectar a la base de datos
    $con = conecta();

    // Preparar la consulta SQL para actualizar el estado del usuario
    $sql = "UPDATE empleados SET status = 0 WHERE id = ?";

    // Preparar la declaración
    $stmt = $con->prepare($sql);

    // Vincular el parámetro
    $stmt->bind_param("i", $id);

    // Ejecutar la consulta
    if ($stmt->execute()) {
        // Si se actualiza correctamente, redirigir a la página de lista
        header("Location: /Proyecto/empleados_lista.php");
        exit(); // Salir del script después de la redirección
    } else {
        // Si hay un error, mostrar el mensaje de error
        echo "Error al actualizar el estado del usuario: " . $stmt->error;
    }

    // Cerrar la conexión y la declaración
    $stmt->close();
    $con->close();
}

// Verificar si se ha enviado el ID del usuario a actualizar
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['id'])) {
        $id = $_POST['id'];
        actualizar_estado_usuario($id);
    } else {
        echo "No se recibió el ID del usuario a actualizar.";
    }
}
?>
