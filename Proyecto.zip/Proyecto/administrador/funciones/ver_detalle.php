<?php
    // ver_detalle.php

require_once("conecta.php");

$con = conecta();
$id = $_GET["id"];
$sql = "SELECT * FROM empleados WHERE id = $id";
$result = $con->query($sql);
$row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalle de Empleado</title>
    <!-- Estilos CSS -->
    <style>
        /* Estilos CSS */
        body {
            font-family: Optima, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #e4fcd8;
        }
        
        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #DAF7A6;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .employee-info {
            margin-bottom: 10px;
        }

        .employee-info strong {
            margin-right: 5px;
            color: #333;
        }

        #password{
            background-color: #eefae8 ; /* Color de fondo del botón */
        }


        h2{
            color:  #44782a ;
        }


        .back-to-list-button {
            background-color: #98b649; /* Color de fondo del botón */
            color: #fff; /* Color del texto del botón */
            border: none; /* Quitamos el borde del botón */
            padding: 8px 16px; /* Espaciado interno del botón */
            border-radius: 3px; /* Borde redondeado */
            cursor: pointer; /* Cambiamos el cursor al pasar sobre el botón */
            text-decoration: none; /* Quitamos el subrayado del enlace */
            display: inline-block; /* Para que el enlace se comporte como un bloque */
            transition: background-color 0.3s; /* Efecto de transición suave */
        }

        .back-to-list-button:hover {
            background-color: #323f0e; /* Cambio de color al pasar el cursor sobre el botón */
        }

        /* Estilos para el encabezado */
        header {
            background-color: #e4fcd8;
            color: #44782a;
            padding: 10px 0;
            text-align: center;
        }
        header h1 {
            margin: 0;
            font-size: 26px;
        }
        /* Estilos para la barra de navegación */
        nav ul {
            list-style-type: none;
            padding: 0;
            text-align: center;
            margin-top: 20px;
        }
        nav ul li {
            display: inline;
            margin-right: 20px;
        }
        nav ul li a {
            text-decoration: none;
            color: #44782a;
            font-size:30px;
        }
        nav ul li a:hover {
            text-decoration: underline;
        }
        header .img{
            max-width: 80px;
            height: auto;
            float: left;

        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #DAF7A6;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            
        }

    </style>
</head>
<body>

    <header>
        <div class="container">
            <img src="/Proyecto/administrador/logo/logoP.jpg" class="img">
            <nav>
                <ul>
                    <li><a href="bienvenido.php">Home</a></li>
                    <li><a href="inicio.php">Empleados</a></li>
                    <li><a href="/Proyecto/productos_lista.php">Productos</a></li>
                    <li><a href="/Proyecto/promociones_lista.php">Promociones</a></li>
                    <li><a href="/Proyecto/productosCerrados.php">Pedidos</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="container">
        <h2>Detalle del empleado</h2>
        <div class="employee-info">
            <strong>ID:</strong><?php echo $row["id"]; ?><br>
            <strong>Nombre:</strong><?php echo $row["nombre"] . " " . $row["apellidos"]; ?><br>
            <strong>Correo:</strong><?php echo $row["correo"]; ?><br>
            <strong>Password:</strong><input id= "password" type="password" value="<?php echo $row["password"]; ?>" readonly><br>
            <strong>Rol:</strong><?php echo $row["rol"]; ?><br>
        </div>
        <a href="/Proyecto/empleados_lista.php" class="back-to-list-button">Regresar al Listado</a><br><br>

    </div>

    <footer style="background-color: #e4fcd8; color: #44782a; text-align: center; padding: 20px;">
        <div>
            <p>Derechos Reservados &copy; <?php echo date("Y"); ?></p>
            <p><a href="#">Términos y Condiciones</a></p>
            <p>Redes Sociales: <a href="#">Facebook</a>, <a href="#">Twitter</a>, <a href="#">Instagram</a></p>
        </div>
    </footer>
    
</body>
</html>
