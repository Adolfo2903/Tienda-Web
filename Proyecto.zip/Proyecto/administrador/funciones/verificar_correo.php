<?php
    // Conectar a la base de datos

require_once("conecta.php");


function verificar_correo_existente($correo) {
    // Conectar a la base de datos
    $con = conecta();

    // Preparar la consulta SQL para verificar si el correo existe
    $stmt = $con->prepare("SELECT correo FROM empleados WHERE correo = ?");
    $stmt->bind_param("s", $correo);
    $stmt->execute();
    $stmt->store_result();
    $num_rows = $stmt->num_rows;
    $stmt->close();
    $con->close();
    
    // Devolver el resultado
    return $num_rows > 0; // Devuelve true si el correo existe, false si no existe
}

// Verificar si se ha enviado el correo a comprobar
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['correo'])) {
        $correo = $_POST['correo'];
        if (verificar_correo_existente($correo)) {
            echo 'existe';
        } else {
            echo 'no_existe';
        }
    } else {
        echo "No se recibió el correo a verificar.";
    }
}

?>