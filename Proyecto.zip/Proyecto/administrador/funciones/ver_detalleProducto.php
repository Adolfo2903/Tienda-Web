<?php
require_once("conecta.php");

$con = conecta();
$id = $_GET["id"];
$sql = "SELECT * FROM productos WHERE id = $id";
$result = $con->query($sql);
$row = $result->fetch_assoc();
// Carpeta donde se almacenan las imágenes
$ruta_imagenes ='../../administrador/fotos_home/';

// Obtener la lista de imágenes disponibles
$imagenes = glob($ruta_imagenes . '*.{jpg,png,gif}', GLOB_BRACE);

// Seleccionar una imagen aleatoria
$imagen_aleatoria = $imagenes[array_rand($imagenes)];

$sql = "SELECT * FROM productos WHERE status = 1 ORDER BY RAND() LIMIT 4";
$result = $con->query($sql);

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalle de Producto</title>
    <!-- Estilos CSS -->
    <style>
        /* Estilos CSS */
        body {
            font-family: Optima, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #e4fcd8;
        }
        
        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #DAF7A6;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .product-info {
            margin-bottom: 10px;
        }

        .product-info strong {
            margin-right: 5px;
            color: #333;
        }

        .back-to-list-button {
            background-color: #155b2a ; /* Color de fondo del botón */
            color: #fff; /* Color del texto del botón */
            border: none; /* Quitamos el borde del botón */
            padding: 8px 16px; /* Espaciado interno del botón */
            border-radius: 3px; /* Borde redondeado */
            cursor: pointer; /* Cambiamos el cursor al pasar sobre el botón */
            text-decoration: none; /* Quitamos el subrayado del enlace */
            display: inline-block; /* Para que el enlace se comporte como un bloque */
            transition: background-color 0.3s; /* Efecto de transición suave */
        }

        .back-to-list-button:hover {
            background-color: #323f0e; /* Cambio de color al pasar el cursor sobre el botón */
        }

        h2{
            color:  #44782a ;
        }
        /* Estilos para el encabezado */
        header {
            background-color: #e4fcd8;
            color: #44782a;
            padding: 10px 0;
            text-align: center;
        }
        header h1 {
            margin: 0;
            font-size: 26px;
        }
        /* Estilos para la barra de navegación */
        nav ul {
            list-style-type: none;
            padding: 0;
            text-align: center;
            margin-top: 20px;
        }
        nav ul li {
            display: inline;
            margin-right: 20px;
        }
        nav ul li a {
            text-decoration: none;
            color: #44782a;
            font-size:30px;
        }
        nav ul li a:hover {
            text-decoration: underline;
        }
        header .img{
            max-width: 80px;
            height: auto;
            float: left;

        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #DAF7A6;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            
        }
        

        /* Estilos para los productos */
        .container_productos {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            align-items: center;
            margin-top: 20px;
            height: 250px;
        }
        .producto {
            width: 200px;
            max-height: auto;
            margin: 20px;
            text-align: center;
            background-color: white;
            padding: 10px;
            border-radius: 10px;
            box-shadow: 0px 0px 20px 0px rgba(0, 0, 0, 0.1);
        }
        .producto img {
            width: 150px;
            height: 150px;
            object-fit: cover;
            border-radius: 10px;
        }
        .producto h4 {
            margin-top: 10px;
            font-size: 20px;
        }
        .producto p {
            margin-top: 5px;
            font-size: 15px;
        }
        h4 {
        color: #155b2a; /* Color del texto del encabezado h4 */
        margin-top: 20px; /* Margen superior */
        font-size: 24px; /* Tamaño de fuente */
        align: center;
        }    
        
    </style>
</head>
<body>
    <header>
        <div class="container">
            <img src="/Proyecto/administrador/logo/logoP.jpg" class="img">
            <nav>
                <ul>
                <li><a href="bienvenido.php">Home</a></li>
                    <li><a href="inicio.php">Empleados</a></li>
                    <li><a href="/Proyecto/productos_lista.php">Productos</a></li>
                    <li><a href="/Proyecto/promociones_lista.php">Promociones</a></li>
                    <li><a href="/Proyecto/productosCerrados.php">Pedidos</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="container">
        <h2>Detalle del producto</h2>
        <div class="product-info">
            <strong>ID:</strong><?php echo $row["id"]; ?><br>
            <strong>Nombre:</strong><?php echo $row["nombre"]; ?><br>
            <strong>Código:</strong><?php echo $row["codigo"]; ?><br>
            <strong>Descripción:</strong><?php echo $row["descripcion"]; ?><br>
            <strong>Costo:</strong><?php echo $row["costo"]; ?><br>
            <strong>Stock:</strong><?php echo $row["stock"]; ?><br>
            <img src="/Proyecto/administrador/fotos_productos/<?php echo $row["archivo"]; ?>" alt="Foto del producto" width="200"><br>
        </div>
        <!--<a href="/Proyecto/productos_lista.php" class="back-to-list-button">Comprar</a><br><br>-->

    </div>

        <!-- Mostrar productos -->
        <div class="container_productos">
            <?php while ($row = $result->fetch_assoc()): ?>
                <div class="producto">
                    <img src="/Proyecto/administrador/fotos_productos/<?php echo $row["archivo"];?>" alt="Imagen del producto">
                    <h4><a href="ver_detalleProductoClientes.php?id=<?php echo $row["id"]; ?>"><?php echo $row["nombre"];?></a></h4>
                    <p><?php echo $row["descripcion"]; ?></p>
                    <p>Precio: <?php echo $row["costo"]; ?></p>
                </div>
            <?php endwhile; ?>
        </div>

        <br><br><br><br><footer style="background-color: #e4fcd8; color: #44782a; text-align: center; padding: 20px;">
        <div>
            <p>Derechos Reservados &copy; <?php echo date("Y"); ?></p>
            <p><a href="#">Términos y Condiciones</a></p>
            <p>Redes Sociales: <a href="#">Facebook</a>, <a href="#">Twitter</a>, <a href="#">Instagram</a></p>
        </div>
    </footer>
        
</body>
</html>
