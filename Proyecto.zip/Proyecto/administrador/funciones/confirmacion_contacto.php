<html>
<head>
    <title>Confirmación de Contacto</title>
    <style>
        body {
            font-family: Optima, sans-serif;
            background-color: #e4fcd8;
            text-align: center;
        }
        .container {
            max-width: 600px;
            margin: 100px auto;
            padding: 20px;
            background-color: #DAF7A6;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #44782a;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>¡Gracias por ponerte en contacto con nosotros!</h1>
        <p>Tu mensaje ha sido recibido correctamente.</p>
        <p>Nos pondremos en contacto contigo lo antes posible.</p>
        <a href="bienvenidoClientes.php">Volver a la página de inicio</a>
    </div>
</body>
</html>
