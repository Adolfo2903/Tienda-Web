<?php
// funciones/eliminar_producto.php
require_once("conecta.php");

function eliminar_producto($id) {
    // Conectar a la base de datos
    $con = conecta();

    // Preparar la consulta SQL para eliminar el producto
    $sql = "UPDATE productos SET status = 0 WHERE id = ?";
    // Preparar la declaración
    $stmt = $con->prepare($sql);

    // Vincular el parámetro
    $stmt->bind_param("i", $id);

    // Ejecutar la consulta
    if ($stmt->execute()) {
        // Si se elimina correctamente, redirigir a la página de lista
        header("Location: /Proyecto/productos_lista.php");
        exit(); // Salir del script después de la redirección
    } else {
        // Si hay un error, mostrar el mensaje de error
        echo "Error al eliminar el producto: " . $stmt->error;
    }

    // Cerrar la conexión y la declaración
    $stmt->close();
    $con->close();
}

// Verificar si se ha enviado el ID del producto a eliminar
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['id'])) {
        $id = $_POST['id'];
        eliminar_producto($id);
    } else {
        echo "No se recibió el ID del producto a eliminar.";
    }
}
?>
