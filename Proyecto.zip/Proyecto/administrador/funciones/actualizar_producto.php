<?php
require_once("conecta.php");

$con = conecta();

// Definir el directorio de destino de las fotos de los productos
$directorio_destino = "/Proyecto/administrador/fotos_productos/";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["id"])) {
    $id = $_POST["id"];
    $nombre = $_POST["nombre"];
    $codigo = $_POST["codigo"];
    $descripcion = $_POST["descripcion"];
    $costo = $_POST["costo"];
    $stock = $_POST["stock"];

    // Verificar si se proporcionó una nueva foto
    if (!empty($_FILES["foto"]["name"])) {
        // Nombre del archivo en el servidor
        $nombre_archivo_real = $_FILES["foto"]["name"];
        // Nombre encriptado para el almacenamiento
        $nombre_archivo_encriptado = md5(uniqid(rand(), true)) . '.' . pathinfo($nombre_archivo_real, PATHINFO_EXTENSION);
        // Ruta donde se almacenará el archivo
        $ruta_archivo_destino = $_SERVER['DOCUMENT_ROOT'] . $directorio_destino . $nombre_archivo_encriptado;
        
        // Mover el archivo cargado al directorio de destino
        if (move_uploaded_file($_FILES["foto"]["tmp_name"], $ruta_archivo_destino)) {
            // Actualizar el nombre de la foto en la base de datos
            $sql = "UPDATE productos SET nombre=?, codigo=?, descripcion=?, costo=?, stock=?, archivo_n=?, archivo=? WHERE id=?";
            $stmt = $con->prepare($sql);
            $stmt->bind_param("sssssssi", $nombre, $codigo, $descripcion, $costo, $stock, $nombre_archivo_real, $nombre_archivo_encriptado, $id);
        } else {
            echo "Error al cargar la foto.";
            exit();
        }
    } else {
        // Si no se proporcionó una nueva foto, actualizar sin modificar el campo de la foto en la base de datos
        $sql = "UPDATE productos SET nombre=?, codigo=?, descripcion=?, costo=?, stock=? WHERE id=?";
        $stmt = $con->prepare($sql);
        $stmt->bind_param("sssssi", $nombre, $codigo, $descripcion, $costo, $stock, $id);
    }

    // Ejecutar la consulta preparada
    if ($stmt->execute()) {
        // Redireccionar a la página de lista de productos después de la actualización
        header("Location: /Proyecto/productos_lista.php");
        exit();
    } else {
        echo "Error al actualizar el producto: " . $con->error;
    }
} else {
    // Redireccionar si no se envían datos POST o no se proporciona el ID del producto
    header("Location: /Proyecto/productos_lista.php");
    exit();
}
?>
