<?php
// verificar_usuarioCliente.php
session_start();
require_once("conecta.php");

// Verificar si se ha enviado el usuario y la contraseña mediante POST
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["usuario"]) && isset($_POST["password"])) {
    $usuario = trim($_POST["usuario"]);
    $password = trim($_POST["password"]);

    // Crear una conexión a la base de datos
    $con = conecta();

    // Preparar la consulta SQL para verificar el usuario
    $stmt = $con->prepare("SELECT id, nombre FROM clientes WHERE correo = ? AND pass = ? AND status = 1");
    $stmt->bind_param("ss", $usuario, $password);
    $stmt->execute();
    $stmt->store_result();
    $num_rows = $stmt->num_rows;

    // Verificar si se encontró el usuario
    if ($num_rows > 0) {
        // Obtener el ID y el nombre del usuario
        $stmt->bind_result($id, $nombre);
        $stmt->fetch();

        // Iniciar sesión y guardar el ID y el nombre del usuario
        $_SESSION['usuario_id'] = $id;
        $_SESSION['usuario'] = $nombre;
        echo 'existe';
    } else {
        echo 'no_existe';
    }

    // Cerrar la conexión y la declaración
    $stmt->close();
    $con->close();
}
?>
