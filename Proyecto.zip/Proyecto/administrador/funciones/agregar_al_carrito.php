<?php
// agregar_al_carrito.php

// Verificar si se recibieron los datos del producto
if (isset($_POST['id_producto'], $_POST['cantidad'], $_POST['precio'])) {
    $idProducto = $_POST['id_producto'];
    $cantidad = $_POST['cantidad'];
    $precio = $_POST['precio'];

    // Aquí deberías realizar la inserción en la tabla del carrito
    // Preparar la consulta SQL
    $sql = "INSERT INTO carrito (id_pedido, id_producto, cantidad, precio) VALUES (NULL, ?, ?, ?)";
    
    // Preparar la sentencia
    $stmt = $con->prepare($sql);
    
    // Vincular los parámetros
    $stmt->bind_param("iid", $idProducto, $cantidad, $precio);
    
    // Ejecutar la consulta
    if ($stmt->execute()) {
        // La inserción fue exitosa
        echo "Producto agregado al carrito correctamente";
    } else {
        // Hubo un error al insertar en la base de datos
        echo "Error al agregar el producto al carrito";
    }

    // Cerrar la conexión y liberar recursos
    $stmt->close();
    $con->close();
} else {
    // Si no se recibieron todos los datos necesarios, devolver un mensaje de error
    echo "Faltan datos del producto";
}
?>
